import 'package:flutter/material.dart';
import '../../db/database_helper.dart';
import '../../models/product.dart';
import '../../models/cart_item.dart';
import '../role_select_screen.dart';
import 'cart_screen.dart';
import 'my_orders_screen.dart';

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  List<Product> _products = [];
  bool _loading = true;
  final Map<int, CartItem> _cart = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final list = await DatabaseHelper.instance.getAllProducts();
    setState(() {
      _products = list;
      _loading = false;
    });
  }

  void _addToCart(Product p) {
    if (p.stock <= 0) return;
    setState(() {
      if (_cart.containsKey(p.id)) {
        final existing = _cart[p.id]!;
        if (existing.quantity < p.stock) {
          existing.quantity++;
        }
      } else {
        _cart[p.id!] = CartItem(product: p);
      }
    });
  }

  void _removeFromCart(Product p) {
    setState(() {
      if (_cart.containsKey(p.id)) {
        final existing = _cart[p.id]!;
        if (existing.quantity > 1) {
          existing.quantity--;
        } else {
          _cart.remove(p.id);
        }
      }
    });
  }

  int get _cartCount =>
      _cart.values.fold(0, (sum, item) => sum + item.quantity);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Products'),
        actions: [
          IconButton(
            icon: const Icon(Icons.receipt_long),
            tooltip: 'My Orders',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const MyOrdersScreen()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const RoleSelectScreen()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _products.isEmpty
              ? const Center(child: Text('Abhi koi product available nahi hai.'))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
                    itemCount: _products.length,
                    itemBuilder: (context, index) {
                      final p = _products[index];
                      final inCart = _cart[p.id];
                      final outOfStock = p.stock <= 0;
                      return Card(
                        margin: const EdgeInsets.only(bottom: 10),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 26,
                                backgroundColor: Colors.indigo[50],
                                child: const Icon(Icons.shopping_bag,
                                    color: Colors.indigo),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(p.name,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16)),
                                    const SizedBox(height: 2),
                                    Text('₹${p.price.toStringAsFixed(2)}',
                                        style: const TextStyle(
                                            color: Colors.indigo,
                                            fontWeight: FontWeight.w600)),
                                    Text(
                                      outOfStock
                                          ? 'Out of stock'
                                          : '${p.stock} available',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: outOfStock
                                            ? Colors.red
                                            : Colors.grey[600],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (outOfStock)
                                const SizedBox()
                              else if (inCart == null)
                                OutlinedButton(
                                  onPressed: () => _addToCart(p),
                                  child: const Text('Add'),
                                )
                              else
                                Row(
                                  children: [
                                    IconButton(
                                      icon: const Icon(Icons.remove_circle_outline),
                                      onPressed: () => _removeFromCart(p),
                                    ),
                                    Text('${inCart.quantity}'),
                                    IconButton(
                                      icon: const Icon(Icons.add_circle_outline),
                                      onPressed: () => _addToCart(p),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
      floatingActionButton: _cartCount > 0
          ? FloatingActionButton.extended(
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CartScreen(cart: _cart),
                  ),
                );
                setState(() {
                  _cart.clear();
                });
                _load();
              },
              icon: const Icon(Icons.shopping_cart),
              label: Text('Cart ($_cartCount)'),
            )
          : null,
    );
  }
}
