import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import '../../db/database_helper.dart';
import '../../models/cart_item.dart';
import '../../models/order.dart';
import 'order_success_screen.dart';

class CartScreen extends StatefulWidget {
  final Map<int, CartItem> cart;
  const CartScreen({super.key, required this.cart});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  bool _placing = false;

  double get _total =>
      widget.cart.values.fold(0.0, (sum, item) => sum + item.total);

  Future<void> _placeOrder() async {
    setState(() => _placing = true);
    final prefs = await SharedPreferences.getInstance();
    final name = prefs.getString('customer_name') ?? 'Customer';
    final phone = prefs.getString('customer_phone') ?? '';

    final items = widget.cart.values
        .map((c) => OrderItem(
              productName: c.product.name,
              price: c.product.price,
              quantity: c.quantity,
            ))
        .toList();

    final order = ShopOrder(
      customerName: name,
      customerPhone: phone,
      items: items,
      total: _total,
      status: 'Pending',
      timestamp: DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.now()),
    );

    await DatabaseHelper.instance.insertOrder(order);

    for (final c in widget.cart.values) {
      if (c.product.id != null) {
        await DatabaseHelper.instance.decrementStock(c.product.id!, c.quantity);
      }
    }

    setState(() => _placing = false);

    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const OrderSuccessScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = widget.cart.values.toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Your Cart')),
      body: items.isEmpty
          ? const Center(child: Text('Cart khali hai'))
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    title: Text(item.product.name),
                    subtitle: Text(
                        '₹${item.product.price.toStringAsFixed(2)} x ${item.quantity}'),
                    trailing: Text(
                      '₹${item.total.toStringAsFixed(2)}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                );
              },
            ),
      bottomNavigationBar: items.isEmpty
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Total:',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold)),
                        Text(
                          '₹${_total.toStringAsFixed(2)}',
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.indigo),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: _placing ? null : _placeOrder,
                        style: FilledButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                        child: _placing
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                    color: Colors.white, strokeWidth: 2),
                              )
                            : const Text('Place Order (Cash on Delivery)'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
