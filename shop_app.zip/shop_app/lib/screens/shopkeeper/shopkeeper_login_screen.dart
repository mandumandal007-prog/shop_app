import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'shopkeeper_dashboard.dart';

class ShopkeeperLoginScreen extends StatefulWidget {
  const ShopkeeperLoginScreen({super.key});

  @override
  State<ShopkeeperLoginScreen> createState() => _ShopkeeperLoginScreenState();
}

class _ShopkeeperLoginScreenState extends State<ShopkeeperLoginScreen> {
  final _shopNameController = TextEditingController();
  final _pinController = TextEditingController();
  bool _isFirstTime = false;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _checkExisting();
  }

  Future<void> _checkExisting() async {
    final prefs = await SharedPreferences.getInstance();
    final savedPin = prefs.getString('shopkeeper_pin');
    final savedName = prefs.getString('shop_name');
    setState(() {
      _isFirstTime = savedPin == null;
      if (savedName != null) _shopNameController.text = savedName;
      _loading = false;
    });
  }

  Future<void> _submit() async {
    final prefs = await SharedPreferences.getInstance();
    if (_isFirstTime) {
      if (_shopNameController.text.trim().isEmpty ||
          _pinController.text.trim().length < 4) {
        _showError('Shop ka naam daalein aur kam se kam 4 digit ka PIN banayein');
        return;
      }
      await prefs.setString('shop_name', _shopNameController.text.trim());
      await prefs.setString('shopkeeper_pin', _pinController.text.trim());
      _goToDashboard();
    } else {
      final savedPin = prefs.getString('shopkeeper_pin');
      if (_pinController.text.trim() == savedPin) {
        _goToDashboard();
      } else {
        _showError('Galat PIN, dobara try karein');
      }
    }
  }

  void _goToDashboard() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const ShopkeeperDashboard()),
    );
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Shopkeeper Login')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 20),
            Icon(Icons.store, size: 70, color: Colors.indigo[400]),
            const SizedBox(height: 24),
            Text(
              _isFirstTime
                  ? 'Naya shop register karein'
                  : 'Welcome back! PIN daalein',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 24),
            if (_isFirstTime) ...[
              TextField(
                controller: _shopNameController,
                decoration: const InputDecoration(
                  labelText: 'Shop ka Naam',
                  prefixIcon: Icon(Icons.storefront),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
            ],
            TextField(
              controller: _pinController,
              keyboardType: TextInputType.number,
              obscureText: true,
              maxLength: 6,
              decoration: InputDecoration(
                labelText: _isFirstTime ? 'Naya PIN banayein' : 'PIN daalein',
                prefixIcon: const Icon(Icons.lock),
                border: const OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: _submit,
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: Text(_isFirstTime ? 'Register & Enter' : 'Login'),
            ),
          ],
        ),
      ),
    );
  }
}
