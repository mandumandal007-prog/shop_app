import 'dart:convert';

class OrderItem {
  final String productName;
  final double price;
  final int quantity;

  OrderItem({
    required this.productName,
    required this.price,
    required this.quantity,
  });

  Map<String, dynamic> toJson() => {
        'productName': productName,
        'price': price,
        'quantity': quantity,
      };

  factory OrderItem.fromJson(Map<String, dynamic> json) => OrderItem(
        productName: json['productName'] as String,
        price: (json['price'] as num).toDouble(),
        quantity: json['quantity'] as int,
      );
}

class ShopOrder {
  final int? id;
  final String customerName;
  final String customerPhone;
  final List<OrderItem> items;
  final double total;
  String status; // Pending, Confirmed, Delivered
  final String timestamp;

  ShopOrder({
    this.id,
    required this.customerName,
    required this.customerPhone,
    required this.items,
    required this.total,
    this.status = 'Pending',
    required this.timestamp,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerName': customerName,
      'customerPhone': customerPhone,
      'items': jsonEncode(items.map((e) => e.toJson()).toList()),
      'total': total,
      'status': status,
      'timestamp': timestamp,
    };
  }

  factory ShopOrder.fromMap(Map<String, dynamic> map) {
    final itemsRaw = jsonDecode(map['items'] as String) as List;
    return ShopOrder(
      id: map['id'] as int?,
      customerName: map['customerName'] as String,
      customerPhone: map['customerPhone'] as String,
      items: itemsRaw
          .map((e) => OrderItem.fromJson(e as Map<String, dynamic>))
          .toList(),
      total: (map['total'] as num).toDouble(),
      status: map['status'] as String,
      timestamp: map['timestamp'] as String,
    );
  }
}
