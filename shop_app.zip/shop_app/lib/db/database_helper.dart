import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/product.dart';
import '../models/order.dart';

class DatabaseHelper {
  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'shop_app.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        stock INTEGER NOT NULL,
        description TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customerName TEXT NOT NULL,
        customerPhone TEXT NOT NULL,
        items TEXT NOT NULL,
        total REAL NOT NULL,
        status TEXT NOT NULL,
        timestamp TEXT NOT NULL
      )
    ''');
  }

  // ---------- PRODUCT CRUD ----------

  Future<int> insertProduct(Product product) async {
    final db = await database;
    return await db.insert('products', product.toMap()..remove('id'));
  }

  Future<List<Product>> getAllProducts() async {
    final db = await database;
    final maps = await db.query('products', orderBy: 'id DESC');
    return maps.map((m) => Product.fromMap(m)).toList();
  }

  Future<int> updateProduct(Product product) async {
    final db = await database;
    return await db.update(
      'products',
      product.toMap(),
      where: 'id = ?',
      whereArgs: [product.id],
    );
  }

  Future<int> deleteProduct(int id) async {
    final db = await database;
    return await db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> decrementStock(int productId, int qty) async {
    final db = await database;
    final result = await db.query('products',
        where: 'id = ?', whereArgs: [productId], limit: 1);
    if (result.isNotEmpty) {
      final current = result.first['stock'] as int;
      final newStock = (current - qty).clamp(0, 1 << 30);
      await db.update('products', {'stock': newStock},
          where: 'id = ?', whereArgs: [productId]);
    }
  }

  // ---------- ORDER CRUD ----------

  Future<int> insertOrder(ShopOrder order) async {
    final db = await database;
    return await db.insert('orders', order.toMap()..remove('id'));
  }

  Future<List<ShopOrder>> getAllOrders() async {
    final db = await database;
    final maps = await db.query('orders', orderBy: 'id DESC');
    return maps.map((m) => ShopOrder.fromMap(m)).toList();
  }

  Future<List<ShopOrder>> getOrdersByCustomer(String phone) async {
    final db = await database;
    final maps = await db.query(
      'orders',
      where: 'customerPhone = ?',
      whereArgs: [phone],
      orderBy: 'id DESC',
    );
    return maps.map((m) => ShopOrder.fromMap(m)).toList();
  }

  Future<int> updateOrderStatus(int id, String status) async {
    final db = await database;
    return await db.update(
      'orders',
      {'status': status},
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
