# Shop App — Shopkeeper & Customer

Ek simple offline Flutter app jisme Shopkeeper apne products manage kar sakta hai aur Customer unhe browse karke order place kar sakta hai (Cash on Delivery). Sara data phone pe hi SQLite database mein local store hota hai — internet ya Firebase ki zaroorat nahi.

## Features
- **Role selection**: Shopkeeper ya Customer
- **Shopkeeper**: Shop register/login (PIN se), products add/edit/delete, incoming orders dekhein aur status update karein (Pending → Confirmed → Delivered)
- **Customer**: Naam/phone se login, products browse karein, cart mein add karein, order place karein (COD), apne purane orders dekhein

## APK Banane Ke Steps (Important)

Is sandbox environment mein Android SDK download nahi ho saka (network restriction), isliye maine poora **source code** taiyar kar diya hai. Aap apne computer pe 5-10 minute mein APK bana sakte hain:

### 1. Flutter Install Karein
Agar pehle se nahi hai: https://docs.flutter.dev/get-started/install se Flutter SDK install karein (Windows/Mac/Linux — sabke liye available hai).

Install ke baad check karein:
```
flutter doctor
```

### 2. Naya Flutter Project Banayein
```
flutter create shop_app
cd shop_app
```

### 3. Is Zip Ke Files Copy Karein
Is zip mein diya `lib/` folder aur `pubspec.yaml` file, newly-created `shop_app` project ke andar **replace** kar dein (overwrite karein).

### 4. Dependencies Install Karein
```
flutter pub get
```

### 5. APK Build Karein
```
flutter build apk --release
```

Build complete hone ke baad APK yahan milegi:
```
build/app/outputs/flutter-apk/app-release.apk
```

Is APK file ko apne Android phone mein transfer karke install kar lein (phone settings mein "Install from unknown sources" allow karna padega).

### Testing (Build se pehle)
Agar phone connect hai ya emulator chal raha hai, directly run bhi kar sakte hain:
```
flutter run
```

## Project Structure
```
lib/
  main.dart                          - App entry point
  models/
    product.dart, order.dart, cart_item.dart
  db/
    database_helper.dart             - SQLite CRUD operations
  screens/
    role_select_screen.dart          - Shopkeeper/Customer choose karein
    shopkeeper/
      shopkeeper_login_screen.dart   - PIN-based login/register
      shopkeeper_dashboard.dart      - Products + Orders tabs
      add_edit_product_screen.dart
    customer/
      customer_login_screen.dart     - Naam/phone entry
      product_list_screen.dart       - Browse + Cart
      cart_screen.dart               - Place order
      order_success_screen.dart
      my_orders_screen.dart
```

## Aage Kya Add Kar Sakte Hain
- Firebase se online sync (multiple shopkeepers, real-time orders)
- UPI/Razorpay payment integration
- Product images upload
- Push notifications (naya order aane par shopkeeper ko)
- Multiple shopkeeper support (abhi single-shop design hai)
